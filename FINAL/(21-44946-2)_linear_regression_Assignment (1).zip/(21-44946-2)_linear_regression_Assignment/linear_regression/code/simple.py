import argparse
import sys

import numpy as np
from matplotlib import pyplot as plt
import numpy.linalg as la


# Compute the sample mean and standard deviations for each feature (column)
# across the training examples (rows) from the data matrix X.
def mean_std(X):
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    return mean, std


# Standardize the features of the examples in X by subtracting their mean and
# dividing by their standard deviation, as provided in the parameters.
def standardize(X, mean, std):
    S = (X - mean) / std
    return S


# Read data matrix X and labels t from text file.
def read_data(file_name):
    data = np.loadtxt(file_name)
    X = data[:, :-1]  # Features are all but the last column
    t = data[:, -1]   # Last column is the label/output
    return X, t


# Implement gradient descent algorithm to compute w = [w0, w1].
def train(X, t, eta, epochs):
    costs = []
    ep = []
    w = np.zeros(X.shape[1])

    N = X.shape[0]  # Number of training examples

    for epoch in range(epochs):
        if epoch % 10 == 0:
            J = compute_cost(X, t, w)
            costs.append(J)
            ep.append(epoch)

        grad = compute_gradient(X, t, w)
        w -= eta * grad

    return w, ep, costs


# Compute RMSE on dataset (X, t).
def compute_rmse(X, t, w):
    N = X.shape[0]
    predictions = np.dot(X, w)
    rmse = np.sqrt(np.sum((predictions - t) ** 2) / N)
    return rmse


# Compute objective function (cost) on dataset (X, t).
def compute_cost(X, t, w):
    N = X.shape[0]
    predictions = np.dot(X, w)
    error = predictions - t
    cost = (1 / (2 * N)) * np.sum(error ** 2)
    return cost


# Compute gradient of the objective function (cost) on dataset (X, t).
def compute_gradient(X, t, w):
    N = X.shape[0]
    predictions = np.dot(X, w)
    error = predictions - t
    grad = (1 / N) * np.dot(X.T, error)
    return grad


# BONUS: Implement stochastic gradient descent algorithm to compute w = [w0, w1].
def train_SGD(X, t, eta, epochs):
    costs = []
    ep = []
    w = np.zeros(X.shape[1])
    N = X.shape[0]

    for epoch in range(epochs):
        if epoch % 10 == 0:
            J = compute_cost(X, t, w)
            costs.append(J)
            ep.append(epoch)

        for i in range(N):
            xi = X[i]
            ti = t[i]
            prediction = np.dot(xi, w)
            error = prediction - ti
            grad = xi * error
            w -= eta * grad

    return w, ep, costs


##======================= Main program =======================##
parser = argparse.ArgumentParser('Simple Regression Exercise.')
parser.add_argument('-i', '--input_data_dir',
                    type=str,
                    default='../data/simple',
                    help='Directory for the simple houses dataset.')
FLAGS, unparsed = parser.parse_known_args()

# Read the training and test data.
Xtrain, ttrain = read_data(FLAGS.input_data_dir + "/train.txt")
Xtest, ttest = read_data(FLAGS.input_data_dir + "/test.txt")

# Compute mean and standard deviation for standardization
mean, std = mean_std(Xtrain)

# Standardize the training and test features
Xtrain_std = standardize(Xtrain, mean, std)
Xtest_std = standardize(Xtest, mean, std)

# Add a column of ones for bias features to the training and test data
Xtrain_std_bias = np.column_stack((np.ones(Xtrain_std.shape[0]), Xtrain_std))
Xtest_std_bias = np.column_stack((np.ones(Xtest_std.shape[0]), Xtest_std))

# Computing parameters for gradient descent for eta=0.1 and 200 epochs
eta = 0.1
epochs = 200
w, eph, costs = train(Xtrain_std_bias, ttrain, eta, epochs)
wsgd, ephsgd, costssgd = train_SGD(Xtrain_std_bias, ttrain, eta, epochs)

# Print model parameters.
print('Params GD: ', w)
print('Params SGD: ', wsgd)

# Print cost and RMSE on training data.
print('Training RMSE (GD): %0.2f.' % compute_rmse(Xtrain_std_bias, ttrain, w))
print('Training cost (GD): %0.2f.' % compute_cost(Xtrain_std_bias, ttrain, w))
print('Training RMSE (SGD): %0.2f.' % compute_rmse(Xtrain_std_bias, ttrain, wsgd))
print('Training cost (SGD): %0.2f.' % compute_cost(Xtrain_std_bias, ttrain, wsgd))

# Print cost and RMSE on test data.
print('Test RMSE (GD): %0.2f.' % compute_rmse(Xtest_std_bias, ttest, w))
print('Test cost (GD): %0.2f.' % compute_cost(Xtest_std_bias, ttest, w))
print('Test RMSE (SGD): %0.2f.' % compute_rmse(Xtest_std_bias, ttest, wsgd))
print('Test cost (SGD): %0.2f.' % compute_cost(Xtest_std_bias, ttest, wsgd))

# Plotting epochs vs. cost for gradient descent methods
plt.xlabel('epochs')
plt.ylabel('cost')
plt.yscale('log')
plt.plot(eph, costs, 'bo-', label='train_jw_gd')
plt.plot(ephsgd, costssgd, 'ro-', label='train_j_w_sgd')
plt.legend()
plt.savefig('gd_cost_simple.png')
plt.close()

# Plotting linear approximation for each training method
plt.xlabel('Floor sizes')
plt.ylabel('House prices')
plt.plot(Xtrain[:, 0], ttrain, 'bo', label='Training data')
plt.plot(Xtest[:, 0], ttest, 'g^', label='Test data')
plt.plot(Xtrain[:, 0], w[0] + w[1] * Xtrain_std[:, 0], 'b', label='GD')
plt.plot(Xtrain[:, 0], wsgd[0] + wsgd[1] * Xtrain_std[:, 0], 'g', label='SGD')
plt.legend()
plt.savefig('train-test-line.png')
plt.close()
